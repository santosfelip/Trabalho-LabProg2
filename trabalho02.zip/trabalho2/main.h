#ifndef MAIN_H_INCLUDED
#define MAIN_H_INCLUDED

#include <stdlib.h>


	typedef struct arq
	{
		struct arq *prox;
		char *nome;
		char *caminhoEmDisco;
	}Arquivo;

	typedef struct pasta
	{
		struct pasta *sub;
		struct pasta *prox;
		Arquivo *lista;
		char *nome;
		int numSubPastas;
		int numArquivos;
	}Pasta;

	//Prot�tipos para o BackUp
    void escreve_arquivo(Pasta *raiz);
    void ler_arquivo(Pasta *raiz);


	//Prot�tipos de arquivos
	int Comandos(int i, char s[], char comando[],int cont,char condicao);
	FILE *open(char *filename,char *type);
	void gravaLinha(FILE *arquivo, char nome[]);
	void Imprime(FILE *file,char nome[]);
	int remover(Pasta **raiz,char *nome);
	void CaminhodeEndereco(char *nome, char *endereco);
	int Voltar(Pasta **raiz,Pasta *aux, char *nome);

	//Prot�tipos para as pastas
	int Cd(Pasta **raiz,char *nome);
	void Inserir(Pasta **raiz,char *nome, char *endereco);
	void print(Pasta *pasta,int comando);

	//Prot�tipo para lista de arquivos
	Arquivo *InserirArquivo(Arquivo **raiz,char *nome,char *endereco);

#endif // MAIN_H_INCLUDED
