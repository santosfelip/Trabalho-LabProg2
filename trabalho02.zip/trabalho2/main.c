#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "main.h"


int main()
{
	Pasta *raiz = NULL;
	Pasta *aux = NULL;
	FILE *file = NULL;
	char s[200];
	char nome[200];
	char comando[6] = " ";
	char nome_pasta[200];
	int cont = 0;
	char endereco[200] = " ";

	system("cls");
	strcpy(nome_pasta,"");
    strcpy(endereco,"C:\\");

    //criando a pasta Raiz C:\\*/
    Inserir(&raiz,"C:\\",endereco);
    raiz->numSubPastas = 0;
    raiz->numArquivos = 0;

    raiz->lista = NULL;

    //Lendo o Arquivo Binario
    ler_arquivo(raiz);

    aux = raiz;
	do
	{
		strcpy(comando,"");
		fflush(stdin);
		printf("%s> ",endereco);
		scanf("%[^\n]s",s);

		//Chamando a fun��o que separa o comando do nome do arquivo
		cont = Comandos(0,s,comando,cont,' ');//<--pegando o comando
		cont = Comandos(cont+1,s,nome,0,'\0');//<--pegando o nome do arquivo

		//Comandos Gerais:
		if(strcmp(comando,"ls")==0){
			print(raiz,2);
		}else{
			if(strcmp(comando,"lsf")==0){
				print(raiz,1);
			}else{
				if(strcmp(comando,"dir")==0){
					print(raiz,0);
				}
			}
		}

		//Comando para pasta
		if(strcmp(comando,"cd")==0){
			if(Cd(&raiz,nome)){
                CaminhodeEndereco(nome, endereco);
			}else{
				printf("MSG: Pasta nao existe!\n");
			}
		}else{
			if(strcmp(comando,"cdb")==0){
                    if(Voltar(&raiz,aux,nome)){
                        printf("%s",raiz->nome);
                    }else
                    {
                        printf("ERRO");
                    }
			}else{
				if(strcmp(comando,"mkdir")==0){
                        Inserir(&raiz,nome,endereco);
				}else{
					if(strcmp(comando,"rm")==0){
						if(remover(&raiz,nome)){

						}else{
                            printf("MSG: ERRO!");
						}
					}else{
						if(strcmp(comando,"mv")==0){
							printf("mv\n");
						}
					}
				}
			}
		}

		//Comando para arquivo
		if(strcmp(comando,"new")==0){

			if(file==NULL){
				file = open(nome,"w");
				if(raiz!=NULL){
                    raiz->lista = InserirArquivo(&raiz->lista,nome,endereco);
                    raiz->numArquivos++;
				}
				fclose(file);
				file=NULL;
			}else{
				printf("MSG: Arquivo ja existe!\n");
			}
		}
		else{
			if(strcmp(comando,"edit")==0){
					gravaLinha(file,nome);
			}
			else{
				if(strcmp(comando,"del")==0){

					if(file!=NULL){
						remove(nome);
						printf("Arquivo removido\n");
						file = NULL;
						fclose(file);
					}else{
						printf("MSG: Arquivo nao existe!\n");
					}

				}
				else{
					if(strcmp(comando,"view")==0){
						Imprime(file,nome);
						printf("..........................\n");
					}
				}
			}
		}

	cont = 0;//reiniciando a vari�vel
	}while(strcmp(comando,"exit")!=0);

    //escrevendo no arquivo de Backup!
    escreve_arquivo(raiz);
	return 0;
}


//Fun��es para escreita e leitura do Arquivo .bin
void escreve_arquivo(Pasta *raiz)
{
    Pasta *aux=raiz;
    FILE *arq;

    arq = fopen("dados.dat","wb");
    if(arq!= NULL)
    {
        while(aux!=NULL){

            fwrite(&aux, sizeof(Pasta), 1, arq);
            aux=aux->prox;
        }
        fclose(arq);
    }
    else{
        printf("ERRO ao abrir o BackUP!\n");
    }
    fclose(arq);
}

void ler_arquivo(Pasta *raiz)
{
    Pasta *aux=raiz;
    FILE *arq;

    arq = fopen("dados.dat","rb");

    if(arq!= NULL)
    {
        while(1){

            size_t r = fread(&aux, sizeof(Pasta),1,arq);

            if(r < 1)
                break;
            else{
                raiz = aux;
            }
        }
        fclose(arq);
    }
    else{
        printf("ERRO ao abrir o BackUP!");
    }
}



//Separando o comando do nome do arquivo;
int Comandos(int i, char s[], char comando[],int cont,char condicao)
{
	char c;
	for(;;i++)
	{
		c = s[i];

		/*condicao de parada, se for para o comando, a condicao � ' '(espa�o),
		se for para o nome do arquivo a condi��o � '\0'(fim da string);*/
		if(c==condicao) break;
		comando[cont] = c;

		cont++;
	}
	comando[cont]='\0';//colocando o '\0' na ultima posi��o;
	return cont;

}

FILE *open(char *filename,char *type)
{
    FILE *file = fopen(filename,type);
    if (file==NULL)
    {
        printf("Erro ao Criar\n");
        return NULL;
    }

    return file;
}


void gravaLinha(FILE *arquivo, char nome[])
{
	char linha[200];
    if (arquivo!=NULL)
    {
    	arquivo = open(nome,"a");
    	printf("Editando: %s\n",nome);
    	printf("..........................\n");
    	do{
    		linha[0] = '\0';
    		fflush(stdin);
    		gets(linha);
    		if (strcmp(linha,":save")!=0 && strcmp(linha,":quit")!=0)
    			fprintf(arquivo,"%s\n",linha);

    	}while(strcmp(linha,":save")!=0 && strcmp(linha,":quit")!=0);
    	printf("..........................\n");
    	printf("MSG: Arquivo salvo com sucesso!\n\n");
    }else{
    	printf("MSG: Arquivo nao existe!\n\n");
    }
    fclose(arquivo);
}


void Imprime(FILE *file, char nome[])
{
	FILE *pont_arq;
  	char texto_str[200];

  	if (file!=NULL){
  		printf("Vendo: %s\n",nome);
    	printf("..........................\n");
  		//abrindo o arquivo_frase em modo "somente leitura"
  		pont_arq = fopen(nome, "r");

  		//enquanto n�o for fim de arquivo o looping ser� executado
  		//e ser� impresso o texto
  		while(fgets(texto_str, 200, file) != NULL)
  		printf("%s", texto_str);

  		//fechando o arquivo
  		fclose(pont_arq);
  	}else{
  		printf("MSG: Arquivo nao existe!\n");
  	}

}

//Mover entre as pastas
int Cd(Pasta **raiz,char *nome)
{
    Pasta *aux=NULL,*anterior=NULL;
    if (*raiz==NULL)
    {
        return 0;
    }
    else
    {
        aux = *raiz;
        while (aux!=NULL && strcmp(aux->nome,nome)!=0)
        {
            anterior = aux;
            aux = aux->prox;
        }

        if (aux==NULL)
        {
            return 0;
        }
        else
        {
            if (anterior==NULL)
            {
                *raiz = aux->prox;
            }
            else
            {
                anterior->prox = aux->prox;
            }
            return 1;
        }
    }
}

void Inserir(Pasta **raiz,char *nome,char *endereco)
{
	Pasta *novo;
	//Alocando memoria
	novo = (Pasta*)malloc(sizeof(Pasta));
	novo->nome = malloc(sizeof(char)*200);
	novo->numSubPastas++;

	//Criando a Lista de Arquivos
    novo->lista = NULL;

    strcpy(novo->nome,nome);

    if (*raiz == NULL)
    {
        novo->prox = NULL;
        novo->sub = NULL;
        *raiz = novo;
    }
    else
    {
        novo->prox = *raiz;
        *raiz = novo;
    }
}

Arquivo *InserirArquivo(Arquivo **raiz,char *nome,char *endereco){

    Arquivo *novo = (Arquivo*)malloc(sizeof(Arquivo));

    novo->nome = malloc(sizeof(char)*30);
    novo->caminhoEmDisco = malloc(sizeof(char)*200);

    strcpy(novo->caminhoEmDisco,endereco);
    strcpy(novo->nome,nome);

    if (*raiz == NULL)
    {
        novo->prox = NULL;
        *raiz = novo;
    }
    else
    {
        novo->prox = *raiz;
        *raiz = novo;
    }

    return novo;
}

int Voltar(Pasta **raiz,Pasta *aux, char *nome)
{
        Pasta *anterior = NULL;
        while (aux!=NULL && strcmp(aux->nome,nome)!=0)
        {
            anterior = aux;
            aux = aux->prox;
        }
        if (aux==NULL)
        {
            return 0;
        }
        else
        {
            if (anterior==NULL)
            {
                return 0;
            }
            anterior = *raiz;
            if(aux->prox->nome == anterior->nome){
                raiz=aux;
            }
            return 1;
        }


}

void print(Pasta *pasta,int comando)
{
    Pasta *aux = pasta;
    Arquivo *aux2 = aux->lista;
    while(aux!=NULL)
    {
            switch(comando){
                case 0://strcmp(comando,"dir")==0
                    printf("%s\n",aux->nome);
                break;

                case 1://strcmp(comando,"lsf")==0
                    if(aux2!=NULL){
                        while(aux2!=NULL){
                            printf("%s\n",aux2->nome);
                            aux2=aux2->prox;
                        }
                    }
                break;

                case 2://strcmp(comando,"ls")==0
                    if(aux!=NULL){
                        printf("%s\n",aux->nome);
                    }
                    while(aux2!=NULL){
                        printf("%s\n",aux2->nome);
                        aux2=aux2->prox;
                    }
                break;
                }

        aux=aux->prox;
    }
}

void CaminhodeEndereco(char *nome, char *endereco)
{
    int i,cont=0,tam = strlen(endereco);

    for(i=tam;cont<strlen(nome);i++){
        endereco[i] = nome[cont];
        cont++;
    }
    endereco[tam+1] = '\\';
}

int remover(Pasta **raiz,char *nome)
{
    Pasta *aux=NULL,*anterior=NULL;
    if (*raiz==NULL)
    {
        return 0;
    }
    else
    {
        aux = *raiz;
        while (aux!=NULL && strcmp(aux->nome,nome)!=0)
        {
            anterior = aux;
            aux = aux->prox;
        }

        if (aux==NULL)
        {
            return 0;
        }
        else
        {
            if (anterior==NULL)
            {
                *raiz= aux->prox;
            }
            else
            {
                anterior->prox = aux->prox;
            }
            free(aux);
            return 1;
        }
    }
}
